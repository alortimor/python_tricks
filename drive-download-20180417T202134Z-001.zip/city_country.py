#!/usr/bin/python3

def show_city_country(city, country):
  """Format 2 strings to a format of City, Country"""
  city_country = city + ', ' + country
  return city_country.title()


