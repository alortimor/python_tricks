#!/usr/bin/python3
words = 'The quick fox jumped over the lazy dog and ate his food!'.spli()
triplet = [[w.upper(), w.lower(), len(w) for w in workds]

for v in triplet:
  print(v)
 