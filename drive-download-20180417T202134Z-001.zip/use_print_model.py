#!/usr/bin/python3

import print_model as pm


printed_designs = ['iphone case', 'robot pendant', 'dodecahedron']
completed_models = []
pm.print_models(pinted_designs, completed_models)
pm.show_completed_models(completed_models)


