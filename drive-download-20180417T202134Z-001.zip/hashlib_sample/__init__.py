#!//usr/bin/python3

from .user import User
authenticator = Authenticator()

