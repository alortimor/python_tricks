#!/usr/bin/python3
import matplotlib
from matplotlib import pyplot

squares = [1,4,9,16,25]
pyplot.plot(squares)
pyplot.show()
